<?php
/*
Plugin Name: CampusConnect Login Helper
Description: Redirects users after login (inkl. WooCommerce), steuert Menü-Sichtbarkeit (Login/Registrieren vs. My Account/Courses) und zeigt eine einfache Kurs-/Fortschrittsübersicht.
Author: ChatGPT & Karolis
Version: 1.6
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direktzugriff verhindern
}

/**
 * Hilfsfunktion: Link zur Courses-Seite holen
 */
function campusconnect_get_courses_url() {
    // Versuche Page mit Slug "courses" zu finden
    $page = get_page_by_path( 'courses' );
    if ( $page ) {
        return get_permalink( $page->ID );
    }

    // Fallback: /courses/ relativ
    return home_url( '/courses/' );
}

/**
 * 1) Standard WordPress Login-Redirect (wp-login.php etc.)
 */
function campusconnect_login_helper_redirect( $redirect_to, $request, $user ) {

    if ( ! ( $user instanceof WP_User ) ) {
        return $redirect_to;
    }

    return campusconnect_get_courses_url();
}
add_filter( 'login_redirect', 'campusconnect_login_helper_redirect', 10, 3 );

/**
 * 2) WooCommerce Login-Redirect (My Account Login-Formular)
 */
function campusconnect_woocommerce_login_redirect( $redirect, $user ) {

    if ( ! ( $user instanceof WP_User ) ) {
        return $redirect;
    }

    return campusconnect_get_courses_url();
}
add_filter( 'woocommerce_login_redirect', 'campusconnect_woocommerce_login_redirect', 10, 2 );

/**
 * 3) WooCommerce Registrierungs-Redirect
 */
function campusconnect_woocommerce_registration_redirect( $redirect ) {
    return campusconnect_get_courses_url();
}
add_filter( 'woocommerce_registration_redirect', 'campusconnect_woocommerce_registration_redirect', 10, 1 );

/**
 * 4) Failsafe: Wenn schon eingeloggt und auf My-Account/Login/Registrieren-Seite,
 *    dann auch rüber auf Courses schicken.
 */
function campusconnect_force_redirect_from_account_pages() {

    if ( ! is_user_logged_in() || is_admin() ) {
        return;
    }

    // WooCommerce "Mein Konto" Seite
    if ( function_exists( 'is_account_page' ) && is_account_page() ) {
        wp_redirect( campusconnect_get_courses_url() );
        exit;
    }

    // Eigene Login-/Registrieren-Seiten (Slug ggf. anpassen)
    if ( is_page( array( 'login', 'register' ) ) ) {
        wp_redirect( campusconnect_get_courses_url() );
        exit;
    }
}
add_action( 'template_redirect', 'campusconnect_force_redirect_from_account_pages' );

/**
 * CSS für Menü-Sichtbarkeit & Kurstabelle
 *
 * Verwendung im Menü (Design > Menüs):
 *  - "Login" + "Registrieren" bekommen die CSS-Klasse: nav-logged-out
 *  - "My Account" + "Courses" bekommen die CSS-Klasse: nav-logged-in
 */
function campusconnect_login_helper_css() {
    ?>
    <style>
        /* Login & Registrieren nur sichtbar, wenn NICHT eingeloggt */
        body.logged-in .nav-logged-out {
            display: none !important;
        }

        /* My Account & Courses nur sichtbar, WENN eingeloggt */
        body:not(.logged-in) .nav-logged-in {
            display: none !important;
        }

        .cc-my-courses {
            max-width: 900px;
            margin: 2rem auto;
        }
        .cc-my-courses h2 {
            margin-bottom: 1rem;
        }
        .cc-course-table {
            width: 100%;
            border-collapse: collapse;
        }
        .cc-course-table th,
        .cc-course-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
    </style>
    <?php
}
add_action( 'wp_head', 'campusconnect_login_helper_css' );

/**
 * Shortcode: [my_courses]
 */
function campusconnect_my_courses_shortcode() {
    if ( ! is_user_logged_in() ) {
        return '<p>Bitte logge dich ein, um deine Kurse zu sehen.</p>';
    }

    $user_id = get_current_user_id();

    $courses = get_posts([
        'post_type'      => 'course',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'title',
        'order'          => 'ASC',
    ]);

    if ( empty( $courses ) ) {
        return '<p>Aktuell sind keine Kurse vorhanden.</p>';
    }

    ob_start();
    ?>
    <div class="cc-my-courses">
        <h2>Meine Kurse</h2>
        <table class="cc-course-table">
            <thead>
                <tr><th>Kurs</th><th>Fortschritt</th></tr>
            </thead>
            <tbody>
                <?php foreach ( $courses as $course ): 
                    $course_id = $course->ID;
                    $meta_key  = 'course_' . $course_id . '_progress';
                    $progress  = get_user_meta( $user_id, $meta_key, true );
                    if ( $progress === '' ) $progress = 0;
                    $progress  = max( 0, min( 100, intval( $progress ) ) );
                ?>
                <tr>
                    <td><?php echo esc_html( get_the_title( $course_id ) ); ?></td>
                    <td>
                        <div style="width:200px;border:1px solid #ccc;border-radius:4px;overflow:hidden;display:inline-block;margin-right:8px;">
                            <div style="height:16px;width:<?php echo $progress; ?>%;background:#4caf50;"></div>
                        </div>
                        <strong><?php echo $progress; ?>%</strong>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('my_courses', 'campusconnect_my_courses_shortcode');
